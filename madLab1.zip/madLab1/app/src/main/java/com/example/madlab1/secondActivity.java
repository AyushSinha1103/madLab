package com.example.madlab1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class secondActivity extends AppCompatActivity {
    Intent i ;
    TextView tv1, tv2;
    String s1, s2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        tv1 = findViewById(R.id.us);
        tv2 = findViewById(R.id.ps);
        i = getIntent();
        s1 = i.getStringExtra("usn");
        s2 = i.getStringExtra("pswd");
        tv1.setText(s1);
        tv2.setText(s2);

    }
}