package com.example.madlab5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText user, pass;
    String username, password;
    Button login, register;
    connection con = new connection(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user = findViewById(R.id.editTextText1);
        pass = findViewById(R.id.editTextText2);

        login = findViewById(R.id.button);
        register = findViewById(R.id.button2);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username = user.getText().toString();
                password = pass.getText().toString();
                int result = con.register(username, password) ;
                if(result == 1)
                    Toast.makeText(MainActivity.this, "REGISTERED", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this, "ERROR ALREADY REGISTERED",Toast.LENGTH_SHORT).show();
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username = user.getText().toString();
                password = pass.getText().toString();
                int result = con.login(username, password);
                if(result == 1) {
                    Toast.makeText(MainActivity.this, "LOGGED IN", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(MainActivity.this, homePage.class);
                    startActivity(i);
                }
                else
                    Toast.makeText(MainActivity.this, "NOT REGISTERED", Toast.LENGTH_SHORT).show();
            }
        });


    }
}