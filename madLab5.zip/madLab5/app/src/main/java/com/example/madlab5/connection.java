package com.example.madlab5;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

public class connection extends SQLiteOpenHelper {

    public connection(Context context) {
        super(context, "data.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table data(username TEXT, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists login");
    }
    public int register(String name, String password) {
        SQLiteDatabase db = this.getWritableDatabase() ;
        ContentValues cv = new ContentValues();
        cv.put("username",name) ;
        cv.put("password",password) ;
        int result = (int)db.insert ("data",null,cv);
        if (result == -1)
            return 0;
        else
            return 1;

    }
    public int login(String name,String password) {
        SQLiteDatabase db = this.getReadableDatabase() ;
        Cursor c = db.rawQuery("select * from data where username=? and password=?",new String[]{name,password});
        if(c.getCount()>0)
            return 1;
        else
            return 0;
    }
}