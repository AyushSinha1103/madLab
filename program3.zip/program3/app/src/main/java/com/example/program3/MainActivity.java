package com.example.program3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragment1 fragment1=new fragment1();
        fragment2 fragment2=new fragment2();
        FragmentManager managerF = getSupportFragmentManager();
        FragmentTransaction Ftransaction = managerF.beginTransaction();
        Ftransaction.add(R.id.frameLayout,fragment1);
        Button b1 = findViewById(R.id.button);
        Button b2 = findViewById(R.id.button2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager managerF = getSupportFragmentManager();
                FragmentTransaction Ftransaction = managerF.beginTransaction();
                Ftransaction.replace(R.id.frameLayout,fragment1);
                Toast.makeText(MainActivity.this,"Changed to Fragment1",Toast.LENGTH_LONG).show();
                        Ftransaction.commit();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager managerF = getSupportFragmentManager();
                FragmentTransaction Ftransaction = managerF.beginTransaction();
                Ftransaction.replace(R.id.frameLayout,fragment2);
                Toast.makeText(MainActivity.this,"Changed to Fragment1",Toast.LENGTH_LONG).show();
                Ftransaction.commit();
            }
        });
    }
}